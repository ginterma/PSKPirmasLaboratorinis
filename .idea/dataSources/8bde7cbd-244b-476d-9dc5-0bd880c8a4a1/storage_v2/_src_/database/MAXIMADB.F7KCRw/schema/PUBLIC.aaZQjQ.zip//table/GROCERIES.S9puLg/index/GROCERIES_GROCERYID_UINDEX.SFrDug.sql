create unique index GROCERIES_GROCERYID_UINDEX
    on GROCERIES ("Grocery_id");

