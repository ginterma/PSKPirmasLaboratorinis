create unique index SHIFTS_SHIFT_ID_UINDEX
    on SHIFTS ("Shift_id");

