create unique index EMPLOYEE_EMPLOYEEID_UINDEX
    on EMPLOYEE ("Employee_id");

